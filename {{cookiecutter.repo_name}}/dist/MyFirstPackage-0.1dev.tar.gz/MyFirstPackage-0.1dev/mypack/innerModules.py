import pexpect

def display(line1):
 print line1
 print "This is the inner module package"

