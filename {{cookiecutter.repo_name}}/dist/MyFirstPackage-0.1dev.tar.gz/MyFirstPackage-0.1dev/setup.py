from distutils.core import setup

setup(
    name='MyFirstPackage',
    version='0.1dev',
    packages=['mypack',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
